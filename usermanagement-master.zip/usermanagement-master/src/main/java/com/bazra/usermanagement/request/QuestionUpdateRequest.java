package com.bazra.usermanagement.request;

public class QuestionUpdateRequest {
	private String question;

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}
	
}
