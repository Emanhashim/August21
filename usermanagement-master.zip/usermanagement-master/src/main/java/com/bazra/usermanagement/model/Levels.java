package com.bazra.usermanagement.model;
/**
 * User Levels
 * @author Bemnet
 *
 */
public enum Levels {
	LEVEL_1,
	LEVEL_2,
	LEVEL_3

}
