package com.bazra.usermanagement.model;

/**
 * Acceptable gender types
 * @author Bemnet
 *
 */
public enum Gender {
	MALE,
	FEMALE
}
